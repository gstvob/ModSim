/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TestSignal.h
 * Author: gstvob
 *
 * Created on 24 de Setembro de 2019, 16:43
 */

#ifndef TESTSIGNAL_H
#define TESTSIGNAL_H

#include "BaseConsoleGenesysApplication.h"

class TestSignal : public BaseConsoleGenesysApplication{
public:
    TestSignal();
public:
    virtual int main(int argc, char** argv);
};
#endif /* TestSignal */

