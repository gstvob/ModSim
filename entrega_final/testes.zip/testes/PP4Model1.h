/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PP4Model1.h
 * Author: gstvob
 *
 * Created on 24 de Setembro de 2019, 16:43
 */

#ifndef PP4MODEL1_H
#define PP4MODEL1_H

#include "BaseConsoleGenesysApplication.h"

class PP4Model1 : public BaseConsoleGenesysApplication{
public:
    PP4Model1();
public:
    virtual int main(int argc, char** argv);
};
#endif /* PP4Model1 */

